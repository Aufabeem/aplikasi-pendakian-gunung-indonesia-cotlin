package com.nopi.fyhiking.model

import java.io.Serializable

class ModelMain : Serializable {
    var strLokasi: String? = null
}