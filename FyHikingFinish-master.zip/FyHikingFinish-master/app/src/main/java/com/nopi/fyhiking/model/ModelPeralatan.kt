package com.nopi.fyhiking.model

import java.io.Serializable

class ModelPeralatan : Serializable {
    var strNamaPeralatan: String? = null
    var strImagePeralatan: String? = null
    var strTipePeralatan: String? = null
    var strDeskripsiPeralatan: String? = null
    var strTipsPeralatan: String? = null
}